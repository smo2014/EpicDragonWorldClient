﻿using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class ItemDatabase : ScriptableObject
{
    [SerializeField]
    public string DBType = "ItemDatabase";

    [SerializeField]
    public List<Items> Item = new List<Items>();
}