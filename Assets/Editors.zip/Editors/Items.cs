﻿using UnityEngine;

public class Items
{
    public int ID;
    public string Title;
    public string Description;
    public Itemtype Itemtype;
    public bool Stackable;
    public int MaxStackSize;
    public int Itemlvl;
    public Sprite Icon;
}
public enum Itemtype
{
    Helmet = 0,
    Chest = 1,
    Gloves = 2,
    Legs = 3,
    Boots =4
}
