﻿using System;
using UnityEditor;
using UnityEngine;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Globalization;

public class ItemsDatabaseEditor : EditorWindow
{
    private static readonly Dictionary<int, ItemHolder> ITEMS = new Dictionary<int, ItemHolder>();

    public int item_id;
    public string slot;

    public List<Item> itemsList = new List<Item>();

    private TopTabState _state;
    private int _width = 400;
    private int _itemIndex = 0;
    public Sprite ico;
    private ItemDatabase _itemDatabase; // TODO ItemDatabase
    private string _itemname;
    private string _dataBasePathFolder = "Assets/Editors/";


    [MenuItem("Epic Dragon World/Item Editor")]
    private static void Init()
    {
        EditorWindow.GetWindow(typeof(ItemsDatabaseEditor), false, "Item Editor");
    }

    public void LoadData()
    {
        string cs = @"server=localhost;userid=root;password=;database=edws";
        MySqlConnection conn = null;

        try
        {
            conn = new MySqlConnection(cs);
            conn.Open();


            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "SELECT * FROM items";
            cmd.Prepare();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Item newItem = new Item();
                newItem.ItemID = reader.GetInt32("item_id");
                newItem.ItemName = reader.GetString("slot");
 //               newItem.Icon = Resources.Load("ItemIcons/Equipment/" + GetItem(newItem.ItemID).GetRecipeFemale().ToString().Replace("_Recipe", "")) as Sprite;
                itemsList.Add(newItem);
            }
        }
        catch (MySqlException ex)
        {
            Debug.Log(ex.ToString());
        }
    }

    public enum TopTabState
    {
        ItemDatabase,
        SpawnDatabase,
        About,
    }

    private void OnGUI()
    {
        TopTab();

        switch (_state)
        {
            case TopTabState.ItemDatabase:
                ShowItemDatabase();
                break;

            case TopTabState.SpawnDatabase:
                //                ShowSpawnDatabase();
                break;

            case TopTabState.About:
                ShowAbout();
                break;
        }
    }

    private void ShowItemDatabase()
    {
        if(itemsList != null) // !=
        {
            GUILayout.Space(10);
            GUILayout.BeginHorizontal();
            _itemname = EditorGUILayout.TextField("Item Title", _itemname as string, GUILayout.Width(_width - 100));

            if (GUILayout.Button("Find Item", GUILayout.ExpandWidth(false)))
            {
                FindItemwithName(_itemname);
            }

            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Save/Load from MySQL", "", GUILayout.Width(150));

            if (GUILayout.Button("Save Item", GUILayout.ExpandWidth(false)))
            {
                SaveItem();
            }
            if (GUILayout.Button("Load Item", GUILayout.ExpandWidth(false)))
            {
                ReadItem(_itemIndex);
            }
            if (GUILayout.Button("Load All Item", GUILayout.ExpandWidth(false)))
            {
                ReadItemList();
            }
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();

            EditorGUILayout.LabelField("Item " + _itemIndex + " of  " + (itemsList.Count).ToString() + " Items", "", GUILayout.Width(150));

            if (GUILayout.Button("<<", GUILayout.ExpandWidth(false)))
            {
                _itemIndex = 1;
            }
            if (GUILayout.Button("<", GUILayout.ExpandWidth(false)))
            {
                if (_itemIndex > 1)
                    _itemIndex--;
            }
            if (GUILayout.Button(">", GUILayout.ExpandWidth(false)))
            {
                if (_itemIndex < itemsList.Count)
                    _itemIndex++;
            }
            if (GUILayout.Button(">>", GUILayout.ExpandWidth(false)))
            {
                _itemIndex = itemsList.Count;
            }
            if (GUILayout.Button("Add", GUILayout.ExpandWidth(false)))
            {
                AddItem();
            }
            GUILayout.EndHorizontal();

            itemsList[_itemIndex - 1].ItemID = EditorGUILayout.IntField("Item ID",
                 itemsList[_itemIndex - 1].ItemID, GUILayout.Width(_width));
            itemsList[_itemIndex - 1].ItemName = EditorGUILayout.TextField("Item Slot", itemsList[_itemIndex - 1].ItemName as string, GUILayout.Width(_width));
 //           itemsList[_itemIndex - 1].Description = EditorGUILayout.TextField("Icon Name", GetItem(itemsList[_itemIndex - 1].ItemID).GetRecipeFemale().Replace("_Recipe", "") as string, GUILayout.Width(_width));
//            itemsList[_itemIndex - 1].Icon = EditorGUILayout.ObjectField("Item Icon", Resources.Load<Sprite>("ItemIcons/" + itemsList[_itemIndex - 1].Description), typeof(Sprite), false, GUILayout.Width(_width)) as Sprite;


            //           _itemDatabase.Item[_itemIndex].Icon = EditorGUILayout.ObjectField("Item Icon", _itemDatabase.Item[_itemIndex].Icon, typeof(Sprite), false, GUILayout.Width(_width)) as Sprite;
            //            _itemDatabase.Item[_itemIndex].Itemtype = (Itemtype)EditorGUILayout.EnumPopup("Item Type", _itemDatabase.Item[_itemIndex].Itemtype, GUILayout.Width(_width));

            GUILayout.Space(10);
        }
    }
    
    void LoadSprite(Sprite _name)
    {

    }

    private void AddItem()
    {
        Items newItem = new Items();
        newItem.Title = _itemname;
        newItem.ID = _itemDatabase.Item.Count;
        _itemDatabase.Item.Add(newItem);
        _itemIndex = _itemDatabase.Item.Count - 1;
    }

    private void ReadItemList()
    {
        itemsList.Clear();

        LoadData();

        if(ITEMS.Count < 1)
        {
            LoadAllItems();
        }
    }

    private void ReadItem(object itemIndex)
    {

    }

    private void SaveItem()
    {
        Debug.Log("TODO: Save Item");
    }

    private void FindItemwithName(string itemname)
    {
        Debug.Log("Find: " + itemname);
    }

    private void TopTab()
    {
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Item Database", GUILayout.ExpandWidth(false)))
        {
            _state = TopTabState.ItemDatabase;
        }

        if (GUILayout.Button("Spawn Database", GUILayout.ExpandWidth(false)))
        {
            _state = TopTabState.SpawnDatabase;
        }

        if (GUILayout.Button("About", GUILayout.ExpandWidth(false)))
        {
            _state = TopTabState.About;
        }
        GUILayout.EndHorizontal();
    }

    private void OnEnable()
    {
        if (itemsList == null && itemsList.Count < 1)
            LoadData(); //??

        _state = TopTabState.ItemDatabase;
    }

    private void ShowAbout()
    {
        GUILayout.Space(10);
        GUILayout.Label("Item System Editor v.1.0", EditorStyles.boldLabel, GUILayout.ExpandWidth(false));
        GUILayout.Space(10);
        GUILayout.Label("Item System with Databases \n for Items Create and Edit \n Spawn Item Database ", GUILayout.ExpandWidth(false));

        GUILayout.Space(10);
    
    }

    public T LoadDatabase<T>(string _databasename, string _folderpath) where T : ScriptableObject
    {
        string _loadPath = _folderpath + _databasename + ".asset";
        T t = (T)((object)AssetDatabase.LoadAssetAtPath(_loadPath, typeof(T)));

        if (!t)
        {
            t = ScriptableObject.CreateInstance<T>();
            AssetDatabase.CreateAsset(t, _loadPath);
            AssetDatabase.SaveAssets();
        }
        return t;
    }

    void LoadAllItems()
    {
        TextAsset data = Resources.Load("data/ItemData") as TextAsset;
        string[] lines = Regex.Split(data.text, "\r\n|\n\r|\n|\r");
        foreach (string line in lines)
        {
            if (line.StartsWith("#"))
            {
                continue;
            }
            string[] values = line.Split(';');
            if (values.Length < 20)
            {
                continue;
            }

            int itemId = int.Parse(values[0]);
            EquipmentItemSlot itemSlot = (EquipmentItemSlot)Enum.Parse(typeof(EquipmentItemSlot), values[1]);
            ItemType itemType = (ItemType)Enum.Parse(typeof(ItemType), values[2]);
            string name = values[3];
            string description = values[4];
            string recipeMale = values[5];
            string recipeFemale = values[6];
            int prefabId = int.Parse(values[7]);
            string[] positionMaleSplit = values[8].Split(',');
            Vector3 positionMale = new Vector3(float.Parse(positionMaleSplit[0], CultureInfo.InvariantCulture), float.Parse(positionMaleSplit[1], CultureInfo.InvariantCulture), float.Parse(positionMaleSplit[2], CultureInfo.InvariantCulture));
            string[] positionFemaleSplit = values[9].Split(',');
            Vector3 positionFemale = new Vector3(float.Parse(positionFemaleSplit[0], CultureInfo.InvariantCulture), float.Parse(positionFemaleSplit[1], CultureInfo.InvariantCulture), float.Parse(positionFemaleSplit[2], CultureInfo.InvariantCulture));
            string[] rotationMaleSplit = values[10].Split(',');
            Quaternion rotationMale = Quaternion.Euler(float.Parse(rotationMaleSplit[0], CultureInfo.InvariantCulture), float.Parse(rotationMaleSplit[1], CultureInfo.InvariantCulture), float.Parse(rotationMaleSplit[2], CultureInfo.InvariantCulture));
            string[] rotationFemaleSplit = values[11].Split(',');
            Quaternion rotationFemale = Quaternion.Euler(float.Parse(rotationFemaleSplit[0], CultureInfo.InvariantCulture), float.Parse(rotationFemaleSplit[1], CultureInfo.InvariantCulture), float.Parse(rotationFemaleSplit[2], CultureInfo.InvariantCulture));
            string[] scaleMaleSplit = values[12].Split(',');
            Vector3 scaleMale = new Vector3(float.Parse(scaleMaleSplit[0], CultureInfo.InvariantCulture), float.Parse(scaleMaleSplit[1], CultureInfo.InvariantCulture), float.Parse(scaleMaleSplit[2], CultureInfo.InvariantCulture));
            string[] scaleFemaleSplit = values[13].Split(',');
            Vector3 scaleFemale = new Vector3(float.Parse(scaleFemaleSplit[0], CultureInfo.InvariantCulture), float.Parse(scaleFemaleSplit[1], CultureInfo.InvariantCulture), float.Parse(scaleFemaleSplit[2], CultureInfo.InvariantCulture));
            bool stackable = bool.Parse(values[14]);
            bool tradable = bool.Parse(values[15]);
            int stamina = int.Parse(values[16]);
            int strength = int.Parse(values[17]);
            int dexterity = int.Parse(values[18]);
            int intelect = int.Parse(values[19]);

            ITEMS.Add(itemId, new ItemHolder(itemId, itemSlot, itemType, name, description, recipeMale, recipeFemale, prefabId, positionMale, positionFemale, rotationMale, rotationFemale, scaleMale, scaleFemale, stackable, tradable, stamina, strength, dexterity, intelect));

        }
    }

    public static ItemHolder GetItem(int id)
    {
        if (!ITEMS.ContainsKey(id))
        {
            return null;
        }
        return ITEMS[id];
    }

}
